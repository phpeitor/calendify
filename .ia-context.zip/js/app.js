
(function(jQuery) {

    "use strict";

    jQuery(document).ready(function() {

        jQuery('[data-toggle="popover"]').popover();
        jQuery('[data-toggle="tooltip"]').tooltip();

        $(window).on('scroll', function () {
            if ($(window).scrollTop() > 0) {
                $('.iq-top-navbar').addClass('fixed');
            } else {
                $('.iq-top-navbar').removeClass('fixed');
            }
        });

        $(window).on('scroll', function () {
            if ($(window).scrollTop() > 0) {
                $('.white-bg-menu').addClass('sticky-menu');
            } else {
                $('.white-bg-menu').removeClass('sticky-menu');
            }
        });

        /*---------------------------------------------------------------------
        Ripple Effect
        -----------------------------------------------------------------------*/
        jQuery(document).on('click', ".iq-waves-effect", function(e) {
            // Remove any old one
            jQuery('.ripple').remove();
            // Setup
            let posX = jQuery(this).offset().left,
                posY = jQuery(this).offset().top,
                buttonWidth = jQuery(this).width(),
                buttonHeight = jQuery(this).height();

            // Add the element
            jQuery(this).prepend("<span class='ripple'></span>");


            // Make it round!
            if (buttonWidth >= buttonHeight) {
                buttonHeight = buttonWidth;
            } else {
                buttonWidth = buttonHeight;
            }

            // Get the center of the element
            let x = e.pageX - posX - buttonWidth / 2;
            let y = e.pageY - posY - buttonHeight / 2;


            // Add the ripples CSS and start the animation
            jQuery(".ripple").css({
                width: buttonWidth,
                height: buttonHeight,
                top: y + 'px',
                left: x + 'px'
            }).addClass("rippleEffect");
        });

       /*---------------------------------------------------------------------
        Sidebar Widget
        -----------------------------------------------------------------------*/

        jQuery(document).on("click", '.iq-menu > li > a', function() {
            jQuery('.iq-menu > li > a').parent().removeClass('active');
            jQuery(this).parent().addClass('active');
        });

        // Active menu
        var parents = jQuery('li.active').parents('.iq-submenu.collapse');

        parents.addClass('show');


        parents.parents('li').addClass('active');
        jQuery('li.active > a[aria-expanded="false"]').attr('aria-expanded', 'true');

        /*---------------------------------------------------------------------
        FullScreen
        -----------------------------------------------------------------------*/
        jQuery(document).on('click', '.iq-full-screen', function() {
            let elem = jQuery(this);
            if (!document.fullscreenElement &&
                !document.mozFullScreenElement && // Mozilla
                !document.webkitFullscreenElement && // Webkit-Browser
                !document.msFullscreenElement) { // MS IE ab version 11

                if (document.documentElement.requestFullscreen) {
                    document.documentElement.requestFullscreen();
                } else if (document.documentElement.mozRequestFullScreen) {
                    document.documentElement.mozRequestFullScreen();
                } else if (document.documentElement.webkitRequestFullscreen) {
                    document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
                } else if (document.documentElement.msRequestFullscreen) {
                    document.documentElement.msRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
                }
            } else {
                if (document.cancelFullScreen) {
                    document.cancelFullScreen();
                } else if (document.mozCancelFullScreen) {
                    document.mozCancelFullScreen();
                } else if (document.webkitCancelFullScreen) {
                    document.webkitCancelFullScreen();
                } else if (document.msExitFullscreen) {
                    document.msExitFullscreen();
                }
            }
            elem.find('i').toggleClass('ri-fullscreen-line').toggleClass('ri-fullscreen-exit-line');
        });


        /*---------------------------------------------------------------------
        Page Loader
        -----------------------------------------------------------------------*/
        jQuery("#load").fadeOut();
        jQuery("#loading").delay().fadeOut("");


        /*---------------------------------------------------------------------
        Counter
        -----------------------------------------------------------------------*/
        if (window.counterUp !== undefined) {
            const counterUp = window.counterUp["default"]
            const $counters = $(".counter");
            $counters.each(function (ignore, counter) {
                var waypoint = new Waypoint( {
                    element: $(this),
                    handler: function() {
                        counterUp(counter, {
                            duration: 1000,
                            delay: 10
                        });
                        this.destroy();
                    },
                    offset: 'bottom-in-view',
                } );
            });
        }


        /*---------------------------------------------------------------------
        Progress Bar
        -----------------------------------------------------------------------*/
        jQuery('.iq-progress-bar > span').each(function() {
            let progressBar = jQuery(this);
            let width = jQuery(this).data('percent');
            progressBar.css({
                'transition': 'width 2s'
            });

            setTimeout(function() {
                progressBar.appear(function() {
                    progressBar.css('width', width + '%');
                });
            }, 100);
        });

        jQuery('.progress-bar-vertical > span').each(function () {
            let progressBar = jQuery(this);
            let height = jQuery(this).data('percent');
            progressBar.css({
                'transition': 'height 2s'
            });
            setTimeout(function () {
                progressBar.appear(function () {
                    progressBar.css('height', height + '%');
                });
            }, 100);
        });



        /*---------------------------------------------------------------------
        Page Menu
        -----------------------------------------------------------------------*/
        jQuery(document).on('click', '.wrapper-menu', function() {
            jQuery(this).toggleClass('open');
        });

        jQuery(document).on('click', ".wrapper-menu", function() {
            jQuery("body").toggleClass("sidebar-main");
        });


        /*---------------------------------------------------------------------
        user toggle
        -----------------------------------------------------------------------*/
        jQuery(document).on('click', '.iq-user-toggle', function() {
            jQuery(this).parent().addClass('show-data');
        });

        jQuery(document).on('click', ".close-data", function() {
            jQuery('.iq-user-toggle').parent().removeClass('show-data');
        });
        jQuery(document).on("click", function(event){
        var $trigger = jQuery(".iq-user-toggle");
        if($trigger !== event.target && !$trigger.has(event.target).length){
            jQuery(".iq-user-toggle").parent().removeClass('show-data');
        }
        });
        /*-------hide profile when scrolling--------*/
        jQuery(window).scroll(function () {
            let scroll = jQuery(window).scrollTop();
            if (scroll >= 10 && jQuery(".iq-user-toggle").parent().hasClass("show-data")) {
                jQuery(".iq-user-toggle").parent().removeClass("show-data");
            }
        });
        let Scrollbar = window.Scrollbar;
        if (jQuery('.data-scrollbar').length) {

            Scrollbar.init(document.querySelector('.data-scrollbar'), { continuousScrolling: false });
        }



        /*---------------------------------------------------------------------
        Form Validation
        -----------------------------------------------------------------------*/

        // Example starter JavaScript for disabling form submissions if there are invalid fields
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);

      /*---------------------------------------------------------------------
       Active Class for Pricing Table
       -----------------------------------------------------------------------*/
      jQuery("#my-table tr th").click(function () {
        jQuery('#my-table tr th').children().removeClass('active');
        jQuery(this).children().addClass('active');
        jQuery("#my-table td").each(function () {
          if (jQuery(this).hasClass('active')) {
            jQuery(this).removeClass('active')
          }
        });
        var col = jQuery(this).index();
        jQuery("#my-table tr td:nth-child(" + parseInt(col + 1) + ")").addClass('active');
      });

        /*------------------------------------------------------------------
        Flatpicker
        * -----------------------------------------------------------------*/
      if (jQuery.fn.flatpickr !== undefined) {
          if (jQuery('.basicFlatpickr').length > 0) {
              //jQuery('.basicFlatpickr').flatpickr();
              flatpickr(".basicFlatpickr", {
                //appendTo: document.querySelector(".modal"),
                static: true,
                dateFormat: "Y-m-d",    
                maxDate: new Date().fp_incr(-6570) 
             });
          }

          if (jQuery('#inputTime').length > 0) {
              jQuery('#inputTime').flatpickr({
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
            });
          }
          if (jQuery('#inputDatetime').length > 0) {
              jQuery('#inputDatetime').flatpickr({
                enableTime: true
            });
          }
          if (jQuery('#inputWeek').length > 0) {
              jQuery('#inputWeek').flatpickr({
                weekNumbers: true
            });
          }
          if (jQuery('#inline-date').length > 0) { 
              jQuery("#inline-date").flatpickr({
                inline: true
            });
          }
          if (jQuery('#inline-date1').length > 0) {
              jQuery("#inline-date1").flatpickr({
                inline: true
            });
          }
      }

        /*---------------------------------------------------------------------
        Scrollbar
        -----------------------------------------------------------------------*/

        jQuery(window).on("resize", function () {
            if (jQuery(this).width() <= 1299) {
                jQuery('#salon-scrollbar').addClass('data-scrollbar');
            } else {
                jQuery('#salon-scrollbar').removeClass('data-scrollbar');
            }
        }).trigger('resize');

        jQuery('.data-scrollbar').each(function () {
            var attr = $(this).attr('data-scroll');
            if (typeof attr !== typeof undefined && attr !== false){
            let Scrollbar = window.Scrollbar;
            var a = jQuery(this).data('scroll');
            Scrollbar.init(document.querySelector('div[data-scroll= "' + a + '"]'));
            }
        });


         /*---------------------------------------------------------------------
           Datatables
        -----------------------------------------------------------------------*/
        if(jQuery('.data-tables').length)
        {
          $('.data-tables').DataTable();
        }

        if ($.fn.select2 !== undefined) {
            $("#single").select2({
                placeholder: "Select a Option",
                allowClear: true
            });
            $("#multiple").select2({
                placeholder: "Select a Multiple Option",
                allowClear: true
            });
            $("#multiple2").select2({
                placeholder: "Select a Multiple Option",
                allowClear: true
            });
        }

        /*---------------------------------------------------------------------
        Pricing tab
        -----------------------------------------------------------------------*/
        jQuery(window).on('scroll', function (e) {

            // Pricing Pill Tab
            var nav = jQuery('#pricing-pills-tab');
            if (nav.length) {
                var contentNav = nav.offset().top - window.outerHeight;
                if (jQuery(window).scrollTop() >= (contentNav)) {
                    e.preventDefault();
                    jQuery('#pricing-pills-tab li a').removeClass('active');
                    jQuery('#pricing-pills-tab li a[aria-selected=true]').addClass('active');
                }
            }
        });


        /*---------- */
        $(".dropdown-menu li a").click(function(){
            var selHtml = $(this).html();
            var selName = $.trim($(this).text())
            $(this).parents('.btn-group').find('.search-replace').html(selHtml);
            $(this).parents('.btn-group').find('.search-query').val(selName);
          });

        /*---------------------------------------------------------------------
        List and Grid
        -----------------------------------------------------------------------*/
        $('.list-grid-toggle').click(function() {
            var txt = $(".icon").hasClass('icon-grid') ? 'List' : 'Grid';
            $('.icon').toggleClass('icon-grid');
            $(".label").text(txt);
          })
          
          $('[data-toggle="pill"]').on('click',function () {
              const extra = $(this).attr('data-extra')
              if (extra !== undefined) {
                  $('.tab-extra').removeClass('active')
                  $(extra).addClass('active')
              }
          })

        $('[data-toggle="pill"]').on('click',function () {
            const extra = $(this).attr('data-extras')
            if (extra !== undefined) {
                $('.filter-extra').removeClass('active')
                $(extra).addClass('active')
            }
        })

        $('[data-placement="daterange"]').daterangepicker({
            opens: 'center'
        }, function(start, end, label) {
            console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
        });

        $('#view-event').on('click', function(e) {
            e.preventDefault()
            $('#view-btn').tab('show');
        })

        $(document).on('click', '[data-extra-toggle="copy"]', function (e) {
            e.preventDefault()
            $(this).attr("title", "Copied!").tooltip("_fixTitle").tooltip("show").attr("title", "Copy to clipboard").tooltip("_fixTitle");
            const input = $(this).data("input")
            copyToClipboard($(input).val())

        })

        $(document).on('click', '[data-extra-toggle="random-text"]', function (e) {
            e.preventDefault()
            const length = $(this).data('length')
            const input = $(this).data('input')
            const target = $(this).data('target')
            const value = random(length)
            $(input).val(value)
            $(target).html(value)
        })

        const urlParams = new URLSearchParams(window.location.search);
        const activeTab = '#' +urlParams.get('activeTab');
        if ($(activeTab).length > 0) {
            $(activeTab).tab('show')
        }

        function random(length) {
            let result = ''
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
            const charactersLength = characters.length
            for (let i = 0; i < length; i++) {
                result += characters.charAt(Math.floor(Math.random() * charactersLength))
            }
            return result
        }

        function copyToClipboard(value) {
            const elem = $("<input>")
            $("body").append(elem);
            elem.val(value).select();
            document.execCommand("copy");
            elem.remove();
        }

        $(document).on('change', '.card-change', function (e) {
            $(this).closest('.event-detail').find('.dropdown').addClass('d-none')
            $(this).closest('.event-detail').addClass('disabled')
            $(this).closest('.event-detail').find('.copy').addClass('d-none')
            $(this).closest('.event-detail').find('.turn-on').removeClass('d-none')
            $(this).closest('.event-detail').find('.card-change').prop('checked', true);
        })

        $(document).on('click', '.turn-on', function(e){
            e.preventDefault()
            $(this).closest('.event-detail').find('.copy').removeClass('d-none')
            $(this).closest('.event-detail').find('.card-change').prop('checked', false);
            $(this).closest('.event-detail').removeClass('disabled')
            $(this).closest('.event-detail').find('.dropdown').removeClass('d-none')
            $(this).addClass('d-none')
        })
    });

    if (jQuery('#calendar1').length) {
        document.addEventListener('DOMContentLoaded', async function () {
            const calendarEl = document.getElementById('calendar1');
            const $profSel = $('select[name="profesional"]');
            const $horaSel = $('select[name="horario"]');

            let eventsData = [];
            let dayEventsCache = [];
            let citasData = [];       
            let selectedDay = null;     

            await loadCitas(); 

            try {
                const res = await fetch('./js/programacion.json', { cache: 'no-store' });
                const json = await res.json();
                const explicitEvents = (json.events || []).map(e => {
                    const out = { ...e };
                    if (!out.title && out.profesional) out.title = out.profesional;
                    return out;
                });

                const citaEvents = (citasData || []).map(ev => {
                    const fecha = (ev.fecha_cita || '').slice(0, 10);
                    const startHH = String(ev.start || '').slice(0, 5);
                    const endHH = String(ev.end || '').slice(0, 5);
                    if (!fecha || !startHH || !endHH) return null;
                    return {
                        profesional: ev.profesional,
                        title: `${ev.nombre || 'Cita'} • ${ev.profesional || 'Profesional'}`,
                        start: `${fecha}T${startHH}:00`,
                        end: `${fecha}T${endHH}:00`,
                        color: '#28a745',
                        textColor: '#ffffff',
                        allDay: false
                    };
                }).filter(Boolean);

                const holidayDates = new Set(
                    explicitEvents
                        .filter(e => e.allDay || e.title === 'FERIADO')
                        .map(e => (e.start || '').slice(0, 10))
                        .filter(Boolean)
                );

                let generatedEvents = [];
                if (json.dailySchedule) {
                    const { profesional, title, startDate, endDate, startTime, endTime, color } = json.dailySchedule;
                    if (profesional && startDate && endDate && startTime && endTime) {
                        const start = new Date(`${startDate}T00:00:00`);
                        const end = new Date(`${endDate}T00:00:00`);
                        const pad = n => String(n).padStart(2, '0');

                        for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
                            const dateStr = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
                            if (holidayDates.has(dateStr)) continue;
                            generatedEvents.push({
                                profesional,
                                title: title || profesional,
                                start: `${dateStr}T${startTime}`,
                                end: `${dateStr}T${endTime}`,
                                color: color || '#17a2b8'
                            });
                        }
                    }
                }

                eventsData = [...generatedEvents, ...explicitEvents, ...citaEvents];
            } catch (err) {
                console.error('No se pudo cargar events.json', err);
            }

            function refreshPicker($el){ if ($el.selectpicker) $el.selectpicker('refresh'); }

            function resetProfesionales() {
                $profSel.empty().append('<option value="">Seleccione profesional..</option>');
                refreshPicker($profSel);
            }

            function resetHorarios() {
                $horaSel.empty().append('<option value="">Seleccione horario..</option>');
                refreshPicker($horaSel);
            }

            const BLOCK_COLOR = '#ffc107';
            const APPT_STEP_MIN = 45;

            function pad2(n){ return String(n).padStart(2,'0'); }
            function minutesFromISO(iso){ const [H,M] = iso.slice(11,16).split(':').map(Number); return H*60 + M; }
            function hmFromMinutes(m){ const h = Math.floor(m/60), mm = m%60; return `${pad2(h)}:${pad2(mm)}`; }

            function makeSlotsAligned(startISO, endISO, step=APPT_STEP_MIN){
                const s = minutesFromISO(startISO), e = minutesFromISO(endISO);
                if (e <= s) return [];
                const offset = (e - s) % step;        
                const first  = s + offset;
                const out = [];
                for (let t = first; t <= e; t += step) out.push(hmFromMinutes(t));
                return out;
            }

            function fillHorarioSlotsForProfessional(pro){
                resetHorarios();
                if (!pro) return;

                const booked = bookedStartsFor(pro, selectedDay);
                const ranges = dayEventsCache
                    .filter(e => e.profesional === pro)
                    .sort((a,b) => a.start.localeCompare(b.start));

                const used = new Set();
                const todayOnly = shouldBlockBeforeEleven(selectedDay || '');
                ranges.forEach(r => {
                    const day = r.start.slice(0,10);
                    const slots = makeSlotsAligned(r.start, r.end, 45);
                    slots.forEach(hhmm => {
                        const slotMinutes = Number(hhmm.split(':')[0]) * 60 + Number(hhmm.split(':')[1]);

                        if (todayOnly && slotMinutes < (11 * 60)) {
                            return;
                        }

                        if (booked.has(hhmm)) {
                            $horaSel.append(`<option value="" disabled>${hhmm} (ocupado)</option>`);
                            return;
                        }

                        const startISO = `${day}T${hhmm}:00`;
                        const endMin   = minutesFromISO(startISO) + 45;
                        const endISO   = `${day}T${hmFromMinutes(endMin)}:00`;
                        const value    = `${startISO}|${endISO}`;

                        if (!used.has(value)) {
                            $horaSel.append(`<option value="${value}">${hhmm}</option>`);
                            used.add(value);
                        }
                    });
                });

                refreshPicker($horaSel);
            }

            function eventCoversDay(e, dateStr) {
                const start = (e.start || '').slice(0, 10);
                if (!start) return false;

                if (e.allDay) {
                    const end = e.end ? e.end.slice(0,10) : start;   
                    return e.end ? (dateStr >= start && dateStr < end) : (dateStr === start);
                }
                return dateStr === start;
            }

            function isBlockedDay(dateStr) {
                return eventsData.some(e =>
                    (e.color || '').toLowerCase() === BLOCK_COLOR &&
                    eventCoversDay(e, dateStr)
                );
            }

            function showAlert(msg, type = 'error') {
                alertify.set('notifier','position', 'top-right');

                switch (type) {
                    case 'success':
                    alertify.success(msg);
                    break;
                    case 'warning':
                    alertify.warning(msg);
                    break;
                    case 'message':
                    case 'info':
                    alertify.message(msg);
                    break;
                    default:
                    alertify.error(msg);
                }
            }

            function populateSelectsForDate(day){
                resetProfesionales(); 
                resetHorarios();

                if (!day) return;
                if (isBlockedDay(day)) { showAlert('Este día está bloqueado', 'warning'); return; }
                if (isPastDay(day)) { showAlert('No puedes seleccionar un día pasado', 'warning'); return; }

                dayEventsCache = eventsData.filter(e => !e.allDay && e.start.slice(0,10) === day);

                if (dayEventsCache.length === 0){
                    showAlert('No hay eventos para este día', 'warning');
                    return;
                }

                const vistos = new Set();
                dayEventsCache.forEach(e=>{
                    if (e.profesional && !vistos.has(e.profesional)){
                        $profSel.append(`<option value="${e.profesional}">${e.profesional}</option>`);
                        vistos.add(e.profesional);
                    }
                });
                refreshPicker($profSel);
            }

            async function loadCitas() {
                try {
                    const res = await fetch('./js/citas.json', { cache: 'no-store' });
                    const json = await res.json();
                    citasData = Array.isArray(json.events) ? json.events : [];
                } catch (e) {
                    console.warn('No se pudo cargar citas.json', e);
                    citasData = [];
                }
            }

            function bookedStartsFor(pro, dayStr) {
                const s = new Set();
                if (!pro || !dayStr) return s;
                citasData.forEach(ev => {
                    if ((ev.profesional || '') === pro && (ev.fecha_cita || '') === dayStr) {
                    const hhmm = String(ev.start || '').slice(0, 5); 
                    if (hhmm) s.add(hhmm);
                    }
                });
                return s;
            }

            function todayLocalYYYYMMDD(){
                const d = new Date();
                d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
                return d.toISOString().slice(0,10); 
            }

            function localMinutesNow() {
                const now = new Date();
                return now.getHours() * 60 + now.getMinutes();
            }

            function shouldBlockBeforeEleven(dateStr) {
                return dateStr === todayLocalYYYYMMDD() && localMinutesNow() >= (11 * 60);
            }

            const todayStr = todayLocalYYYYMMDD();
            const $fc = $('#fecha_cita');
            const $dniInput = $('#dni');
            const $nombreInput = $('#nombre');
            const API_DNI_URL = window.API_DNI_URL || 'https://api.apis.net.pe/v1/dni?numero=';
            const API_DNI_URL_2 = window.API_DNI_URL_2 || 'https://panuts.com/wp-json/pvm/v1/documents/check?type=dni&val=';

            function buildNombreFromDni(data) {
                const candidates = [
                    data?.nombres,
                    data?.nombre,
                    data?.name,
                    data?.names,
                    data?.full_name,
                    data?.persona?.nombres,
                    data?.persona?.nombre,
                    Array.isArray(data?.nombres_completos) ? data.nombres_completos.join(' ') : ''
                ].filter(Boolean);

                const nombres = candidates.find(v => typeof v === 'string' && v.trim()) || '';
                const apellidoPaterno = [
                    data?.apellidoPaterno,
                    data?.ap_paterno,
                    data?.last_name,
                    data?.apellido_paterno,
                    data?.persona?.apellidoPaterno,
                    data?.persona?.apellido_paterno
                ].find(v => typeof v === 'string' && v.trim()) || '';
                const apellidoMaterno = [
                    data?.apellidoMaterno,
                    data?.ap_materno,
                    data?.mother_last_name,
                    data?.apellido_materno,
                    data?.persona?.apellidoMaterno,
                    data?.persona?.apellido_materno
                ].find(v => typeof v === 'string' && v.trim()) || '';

                const full = [nombres.trim(), `${apellidoPaterno} ${apellidoMaterno}`.trim()].filter(Boolean).join(' ');
                return full || (typeof data?.nombre_completo === 'string' ? data.nombre_completo.trim() : '');
            }

            async function consultarDni(dni) {
                if (!/^\d{8}$/.test(String(dni))) return;

                const endpoints = [
                    {
                        url: `${API_DNI_URL}${dni}`,
                        options: { headers: { Accept: 'application/json' } }
                    },
                    {
                        url: `${API_DNI_URL_2}${dni}`,
                        options: { headers: { Accept: 'application/json' } }
                    }
                ];

                for (const endpoint of endpoints) {
                    try {
                        const res = await fetch(endpoint.url, endpoint.options);
                        if (!res.ok) continue;
                        const data = await res.json();
                        const nombreCompleto = buildNombreFromDni(data);
                        if (nombreCompleto) {
                            $nombreInput.val(nombreCompleto);
                            return;
                        }
                    } catch (err) {
                        console.warn('Consulta de DNI fallida:', err);
                    }
                }

                $nombreInput.val('');
                showAlert('No se pudo obtener el nombre con ese DNI', 'warning');
            }

            $dniInput.on('input', function () {
                const raw = (this.value || '').replace(/\D/g, '').slice(0, 8);
                this.value = raw;

                if (raw.length !== 8) {
                    $nombreInput.val('');
                    return;
                }

                const dni = raw;
                clearTimeout(window.__dniLookupTimer);
                window.__dniLookupTimer = setTimeout(() => consultarDni(dni), 500);
            });

            $fc.attr('min', todayStr);

            $fc.on('input change blur', function () {
                const v = (this.value || '').slice(0,10);
                if (v && v < todayStr) {
                    this.value = '';    
                    showAlert('Ingrese una fecha correcta', 'warning'); 
                }
            });

            function isPastDay(dateStr) {
                return dateStr < todayLocalYYYYMMDD();
            }

            $('#fecha_cita').on('change', function(){
                const day = this.value.slice(0,10); 
                selectedDay = day;  
                populateSelectsForDate(day);
            });

            const calendar1 = new FullCalendar.Calendar(calendarEl, {
                selectable: true,
                plugins: ["timeGrid", "dayGrid", "list", "interaction"],
                timeZone: "UTC",
                defaultView: "dayGridMonth",
                contentHeight: "auto",
                eventLimit: true,
                dayMaxEvents: 4,
                header: { left: "prev,next today", center: "title", right: "dayGridMonth,timeGridWeek,timeGridDay,listWeek" },
                dateClick: function (info) {
                    const day = info.dateStr.slice(0,10);
                    selectedDay = day; 
                    if (isBlockedDay(day)) return;
                    if (isPastDay(day)) return;

                    dayEventsCache = eventsData.filter(e => !e.allDay && e.start.slice(0,10) === day);

                    if (dayEventsCache.length === 0) {
                        showAlert('Sin programación para el día: '+ day, 'warning');
                        return;
                    }

                    $('#fecha_cita').val(day);
                    resetProfesionales(); resetHorarios();
                    const vistos = new Set();
                    dayEventsCache.forEach(e => {
                        if (e.profesional && !vistos.has(e.profesional)) {
                            $profSel.append(`<option value="${e.profesional}">${e.profesional}</option>`);
                            vistos.add(e.profesional);
                        }
                    });
                    
                    if ($('.selectpicker').length) $('.selectpicker').selectpicker('refresh');
                    $('#date-event').modal('show');
                },
                events: eventsData
            });

            calendar1.render();

            $('[name="profesional"]').off('change.gen45').on('change.gen45', function(){
                const pro = $(this).val();
                fillHorarioSlotsForProfessional(pro);
            });

            $('[name="horario"]').off('change.keep').on('change.keep', function(){
                const val = $(this).val(); 
            });

            $(document).on("submit", "#submit-schedule", async function (e) {
                e.preventDefault();
                const $f = $(this);
                const profesional = $f.find('#profesional').val();
                const nombre      = $f.find('#nombre').val();
                const correo      = $f.find('#correo').val();
                const dni         = $f.find('#dni').val();
                const telefono    = $f.find('#telefono').val();
                const direccion   = $f.find('#direccion').val();
                const comentario  = $f.find('#comentario').val();
                const fecha_cita  = $f.find('#fecha_cita').val();
                const horarioVal  = $f.find('select[name="horario"]').val() || '';
                const [start, end] = horarioVal.split('|');

                if (!profesional || !nombre || !fecha_cita || !start || !end) {
                    showAlert('Completa los campos obligatorios', 'warning');
                    return;
                }

                if (fecha_cita === todayLocalYYYYMMDD() && Number(start.slice(11, 13)) < 11) {
                    showAlert('No puedes registrar una cita antes de las 11:00 de hoy', 'warning');
                    return;
                }

                const payload = {
                    profesional, nombre, correo, dni, telefono, direccion, comentario,
                    fecha_cita, start, end
                };

                const $btn = $f.find('button[type="submit"]');

                alertify.confirm('¿Desea agendar su cita?',
                async function onOk () {
                    const savingToast = alertify.message('Guardando…', 0) 
                    try {
                        $btn.prop('disabled', true);

                        const res  = await fetch('php/save_cita.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
                        body: JSON.stringify(payload)
                        });

                        const json = await res.json();
                        if (!res.ok || !json.ok) throw new Error(json.error || 'No se pudo guardar');

                        savingToast.dismiss();   
                        showAlert('Cita guardada correctamente', 'success');
                        await loadCitas();
                        fillHorarioSlotsForProfessional(profesional);
                        $('#date-event').modal('hide');
                        $f[0].reset();
                    } catch (err) {
                        savingToast.dismiss();    
                        showAlert(`Error: ${err.message || err}`, 'error');
                    } finally {
                        $btn.prop('disabled', false);
                    }
                },
                function onCancel () { 
                    showAlert('Operación cancelada', 'message');
                }
                ).set('title', 'Confirmación de cita')
                .set('labels', { ok: 'Aceptar', cancel: 'Cancelar' })
                .set('closable', false);
            });
        });
    }

    $('[data-toggle="tooltip"]').tooltip();
    if (jQuery("#editor").length) {
        new Quill('#editor', {theme: 'snow'});
    }

    if (jQuery("#quill-toolbar").length) {
        new Quill('#quill-toolbar', { modules: { toolbar: '#quill-tool' }, placeholder: 'Compose an epic...', theme: 'snow' });
        $('.ql-italic').mouseover();
        setTimeout(function() {
            $('.ql-italic').mouseout();
        }, 2500);
    }

    const readURL = function(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();

            reader.onload = function (e) {
                $('.profile-pic').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $(".file-upload").on('change', function(){
        readURL(this);
    });

    $(".upload-button").on('click', function() {
       $(".file-upload").trigger('click');
    });

    document.querySelectorAll('[data-open]').forEach(el => {
        el.addEventListener('click', e => {
        e.preventDefault(); 
        const dlg = document.getElementById(el.getAttribute('data-open'));
        if (dlg) dlg.showModal();
        });
    });

    document.querySelectorAll('[data-close]').forEach(btn => {
        btn.addEventListener('click', () => {
        btn.closest('dialog').close();
        });
    });

    /*-------------------------------------------------
                    Wizard Form
    ------------------------------------------------*/
    const wizardElem = document.getElementsByClassName('form-wizard')
    Array.from(wizardElem, (elem) => {
        const nextBtn = elem.querySelectorAll('.next')
        const prevBtn = elem.querySelectorAll('.previous')
        const tabs = elem.querySelector('.tab-items')
        if (tabs !== undefined && tabs !== null) {
            const items = tabs.querySelectorAll('li')
            Array.from(items, (item) => {
                item.addEventListener('click', () => {
                    console.log('test')
                })
            })
        }
        if (nextBtn !== undefined && nextBtn !== null) {
            Array.from(nextBtn, (btn) => {
                btn.addEventListener('click', (elemNext) => {
                    const currentPan = btn.closest('fieldset')
                    currentPan.classList.remove('active')
                    currentPan.style.display = 'none'
                    currentPan.nextElementSibling.style.display = 'block'
                    currentPan.nextElementSibling.classList.add('active')
                })
            })
        }
        if (prevBtn !== undefined && prevBtn !== null) {
            Array.from(prevBtn, (btn) => {
                btn.addEventListener('click', (elemNext) => {
                    const currentPan = btn.closest('fieldset')
                    currentPan.classList.remove('active')
                    currentPan.style.display = 'none'
                    currentPan.previousElementSibling.style.display = 'block'
                    currentPan.previousElementSibling.classList.add('active')
                })
            })
        }
    })
})(jQuery);
